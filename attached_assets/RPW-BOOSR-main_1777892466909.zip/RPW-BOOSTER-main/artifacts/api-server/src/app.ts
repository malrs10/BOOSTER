import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import path from "path";
import { fileURLToPath } from "url";
import router from "./routes/index.js";
import { logger } from "./lib/logger.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) { return { id: req.id, method: req.method, url: req.url?.split("?")[0] }; },
      res(res) { return { statusCode: res.statusCode }; },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

// Serve built frontend in production
// Looks for the static dir relative to the compiled dist/ output:
//   - Docker/Railway: ./dist/../public  => /app/public/
//   - Render/raw node: artifacts/api-server/dist/../public => artifacts/api-server/public (fallback)
// Both are populated by the respective build steps.
if (process.env.NODE_ENV === "production") {
  const staticDir = path.resolve(__dirname, "../public");
  app.use(express.static(staticDir));
  app.get("/*path", (_req, res) => {
    res.sendFile(path.join(staticDir, "index.html"));
  });
}

export default app;
